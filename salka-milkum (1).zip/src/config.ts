/**
 * Configuration and constants for Loupe
 * Document 2, Section 5.3
 */

export const APP_NAME = 'Loupe';
export const TAGLINE = 'See the design. Rebuild it exactly.';
export const PIPELINE_VERSION = '1.0.0';

// Gemini model id - primary and fallbacks (pinned ids only)
export const GEMINI_MODEL = 'gemini-3.5-flash-lite';
export const GEMINI_FALLBACK_MODELS = ['gemini-3.1-flash-lite', 'gemini-3-flash-preview'];

export const GEN_CONFIG = {
  maxOutputTokens: 32000,
  thinkingConfig: {
    thinkingBudget: 1024,
  },
};

export const MAX_FILES = 8;
export const MAX_FILE_MB = 10;
export const MIN_WIDTH = 200;
export const MIN_HEIGHT = 150;
export const MAX_DIM = 12000;
export const BLUR_THRESHOLD = 0.5;
export const MAX_SEGMENTS = 12;
export const SEGMENT_RATIO = 1.25;
export const TALL_RATIO = 2.2;
export const AI_MAX_SIDE = 2048;
export const AI_JPEG_QUALITY = 0.9;
export const RETRY_DELAYS_MS = [5000, 15000, 30000];
export const CALL_TIMEOUT_MS = 90000;
export const SCHEMA_RETRIES = 2;
export const COLOR_SNAP_DISTANCE = 40;
export const COLOR_MERGE_DISTANCE = 24;
export const HISTORY_MAX = 50;
export const SHARE_IMAGE_MAX_BYTES = 600000;
export const COVER_WIDTH = 480;
export const COVER_MAX_BYTES = 50000;
export const LIBRARY_FIRST_PAGE = 48;
export const LIBRARY_PAGE = 24;
export const AUTH_ENABLED = false;
export const PAYMENTS_ENABLED = false;

// Standard controlled vocabularies for tagging
export const INDUSTRY_TAGS = [
  'ai-tech',
  'saas',
  'fintech',
  'agency',
  'e-commerce',
  'developer-tools',
  'portfolio',
  'crypto-web3',
  'health-wellness',
  'media-editorial',
] as const;

export const STYLE_TAGS = [
  'dark',
  'light',
  'minimal',
  'enterprise',
  'retro-cyber',
  'playful',
  'monochrome',
  'brutalist',
  'high-contrast',
] as const;

export const SECTION_TAGS = [
  'hero',
  'pricing',
  'features',
  'faq',
  'testimonials',
  'navigation',
  'footer',
  'cta',
  'dashboard',
  'form',
] as const;

export const ANALYZE_PROMPT = `You are Loupe's screenshot inspection engine.
Analyze the provided website or application interface screenshot(s) carefully.

TASK:
1. Verify if the provided images are legitimate screenshots of a website, web application, dashboard, landing page, mobile web view, UI component, or digital interface design.
   - Set isWebsite to true for ANY digital website, web app, dashboard, mobile UI, or design mockup.
   - ONLY set isWebsite to false if the image is NOT a digital user interface at all (e.g. photos of real animals, nature, people, physical objects, non-UI artwork, or memes) or contains adult/unsafe material.
2. Determine if the screenshots belong to ONE website or MULTIPLE different websites.
3. Group the screenshots by website. For each website group:
   - id: a unique short slug (e.g. "site-1", "aeline-ai")
   - label: concise descriptive label in the format "<Brand/Site name>: <Type of site>" (e.g. "Aeline: AI consulting landing page", "Northfield: Fintech pricing page")
   - description: 1 short sentence summarizing what the site is
   - sections: array of detected section types (e.g. ["hero", "features", "pricing", "faq"])
   - imageIndices: array of 0-based indices corresponding to the input images belonging to this site (e.g. [0, 1])

REJECTION CODES (ONLY USE IF NOT A DIGITAL UI/WEBSITE):
- 'not_website': image is completely unrelated to websites/apps (e.g. photo of an animal, landscape, real-world object)
- 'adult_or_unsafe': contains adult, NSFW, or unsafe content
- 'unreadable': image is completely corrupted or pitch black

Return ONLY valid JSON matching this schema:
{
  "isWebsite": boolean,
  "rejectionCode": string | null,
  "rejectionReason": string | null,
  "sites": [
    {
      "id": string,
      "label": string,
      "description": string,
      "sections": string[],
      "imageIndices": number[]
    }
  ]
}`;

export const EXTRACT_PROMPT = `You are Loupe's precision design system extractor.
Your job is to look closely at the provided website screenshot(s) and measured palette, and extract an exhaustive, accurate design specification into structured JSON.

PRECISION GUIDELINES:
1. Examine the visual hierarchy: background floor, elevated card surfaces, input fields, modals.
2. Identify brand typography: display/headline fonts, body font, utility/mono font, weight patterns, letter spacing.
3. Identify color tokens: background, surface layers, primary CTA color, text colors (high contrast heading, body text, muted labels, hairline borders).
4. Measure spacing and shapes: base spacing unit (usually 4px or 8px), border radii for buttons, cards, images, inputs, and elevation shadows/borders.
5. Component specs: analyze the primary CTA button (radius, padding, font, colors), navigation, standard cards, text inputs, status tags/pills.
6. Provide concrete, actionable Do's and Don'ts directly observed from the design.

OUTPUT FORMAT:
Return ONLY valid JSON strictly matching this schema structure:
{
  "meta": {
    "title": "Short title max 60 chars",
    "theme": "dark" | "light" | "mixed",
    "industry": "e.g. saas, fintech, ai-tech, devtools, ecommerce",
    "styleTags": ["minimal", "dark"],
    "sections": ["hero", "features", "pricing"],
    "summary": "1 sentence high-level summary",
    "description": "2-3 sentences architectural overview"
  },
  "colors": [
    {
      "name": "Signal Blue",
      "value": "#0063E1",
      "token": "--color-signal-blue",
      "role": "Primary CTA fill and active indicators"
    }
  ],
  "typography": {
    "primaryFont": {
      "name": "Inter",
      "substitute": "system-ui, -apple-system, sans-serif",
      "role": "Headlines and body copy",
      "weights": [400, 600],
      "sizes": [14, 16, 24, 48],
      "lineHeight": "1.4",
      "letterSpacing": "-0.01em",
      "token": "--font-primary"
    },
    "typeScale": [
      {
        "role": "display",
        "family": "Inter",
        "weight": 600,
        "size": "48px",
        "lineHeight": "1.1",
        "letterSpacing": "-0.03em",
        "token": "--text-display"
      },
      {
        "role": "body",
        "family": "Inter",
        "weight": 400,
        "size": "16px",
        "lineHeight": "1.5",
        "letterSpacing": "0em",
        "token": "--text-body"
      }
    ]
  },
  "spacing": {
    "baseUnit": 4,
    "density": "comfortable",
    "scale": [
      { "name": "base", "value": "16px", "token": "--spacing-16" }
    ],
    "radii": [
      { "element": "buttons", "value": "8px", "token": "--radius-button" },
      { "element": "cards", "value": "16px", "token": "--radius-card" }
    ],
    "shadows": [
      { "name": "subtle", "value": "0 2px 8px rgba(0,0,0,0.1)", "token": "--shadow-subtle" }
    ],
    "layout": {
      "pageMaxWidth": "1200px",
      "sectionGap": "80px",
      "cardPadding": "24px",
      "elementGap": "20px"
    }
  },
  "surfaces": [
    { "level": 0, "name": "Canvas Floor", "value": "#000000", "purpose": "Page canvas floor" }
  ],
  "components": [
    {
      "name": "Primary Button",
      "role": "Primary Call to Action",
      "description": "Solid CTA button with rounded corners",
      "props": { "variant": "primary", "size": "md" },
      "tokensUsed": ["--color-signal-blue", "--radius-button"]
    }
  ],
  "dosAndDonts": {
    "dos": ["Use high contrast heading hierarchy", "Follow standard 4px spacing rhythm"],
    "donts": ["Do not mix inconsistent button border radii", "Do not use arbitrary colors without tokens"]
  }
}`;
