/**
 * Remote / Community storage adapter for Loupe shares and public library
 * Document 2, Section 5.7 & 5.11
 */
import { nanoid } from 'nanoid';
import { ShareDoc, ShareImageDoc, Result, ResultImage } from '../types';
import { getDeviceId } from './local';

const STORAGE_KEY_SHARES = 'loupe_shares';
const STORAGE_KEY_IMAGES = 'loupe_share_images';

// Initial curated community items
const initialCuratedShares: (ShareDoc & { id: string })[] = [
  {
    id: 'rekki-enterprise',
    title: 'REKKI: Midnight Enterprise Control Room',
    markdown: `# REKKI — Style Reference\n> Mission control dashboard in a darkroom\n\n**Theme:** dark\n\nREKKI is a midnight enterprise control room: a pitch-black canvas hosting dense product interfaces that glow from within. One electric blue (#0063E1) does all the emotional heavy lifting on CTAs and active states.\n\n## Tokens — Colors\n| Name | Value | Token | Role |\n|---|---|---|---|\n| Signal Blue | \`#0063E1\` | \`--color-signal-blue\` | Primary CTA fill, active nav indicator |\n| Obsidian | \`#000000\` | \`--color-obsidian\` | Page canvas, dominant background |\n| Carbon | \`#040910\` | \`--color-carbon\` | Card surface base |\n| Graphite | \`#0D0D0D\` | \`--color-graphite\` | Elevated card surfaces |\n| Ash | \`#858585\` | \`--color-ash\` | Body text, muted labels |\n| Paper | \`#FFFFFF\` | \`--color-paper\` | High contrast highlights |`,
    tags: {
      industry: ['ai-tech', 'developer-tools'],
      style: ['dark', 'minimal', 'dense'],
      sections: ['hero', 'features', 'pricing'],
    },
    imageCount: 1,
    coverImage: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="480" height="300" viewBox="0 0 480 300"%3E%3Crect width="480" height="300" fill="%23040910"/%3E%3Ccircle cx="240" cy="150" r="40" fill="%230063E1" opacity="0.8"/%3E%3Ctext x="240" y="240" font-family="sans-serif" font-size="16" fill="%23858585" text-anchor="middle"%3EREKKI Style Reference%3C/text%3E%3C/svg%3E',
    deviceId: 'system',
    createdAt: Date.now() - 86400000 * 3,
    copyCount: 142,
    visibility: 'public',
    publicAt: Date.now() - 86400000 * 3,
    publicCopyCount: 142,
  },
  {
    id: 'aeline-consulting',
    title: 'Aeline: AI Consulting Landing Page',
    markdown: `# Aeline — Style Reference\n> Crisp generative AI advisory\n\n**Theme:** dark\n\n## Tokens — Colors\n| Name | Value | Token | Role |\n|---|---|---|---|\n| Deep Navy | \`#080C14\` | \`--color-bg\` | Page background |\n| Electric Indigo | \`#4F46E5\` | \`--color-primary\` | Primary accent and CTA |\n| Muted Violet | \`#A5B4FC\` | \`--color-text-muted\` | Secondary text |`,
    tags: {
      industry: ['ai-tech', 'agency'],
      style: ['dark', 'clean', 'corporate'],
      sections: ['hero', 'testimonials'],
    },
    imageCount: 1,
    coverImage: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="480" height="300" viewBox="0 0 480 300"%3E%3Crect width="480" height="300" fill="%23080C14"/%3E%3Crect x="180" y="120" width="120" height="60" rx="8" fill="%234F46E5"/%3E%3Ctext x="240" y="230" font-family="sans-serif" font-size="16" fill="%23A5B4FC" text-anchor="middle"%3EAeline AI Advisory%3C/text%3E%3C/svg%3E',
    deviceId: 'system',
    createdAt: Date.now() - 86400000 * 6,
    copyCount: 89,
    visibility: 'public',
    publicAt: Date.now() - 86400000 * 6,
    publicCopyCount: 89,
  },
  {
    id: 'northfield-fintech',
    title: 'Northfield: Fintech Pricing & Checkout',
    markdown: `# Northfield — Style Reference\n> Modern institutional fintech\n\n**Theme:** light\n\n## Tokens — Colors\n| Name | Value | Token | Role |\n|---|---|---|---|\n| Pure White | \`#FFFFFF\` | \`--color-bg\` | Base surface |\n| Forest Emerald | \`#047857\` | \`--color-primary\` | Confirmation & Trust |\n| Slate Ink | \`#0F172A\` | \`--color-text\` | High-legibility text |`,
    tags: {
      industry: ['fintech', 'saas'],
      style: ['light', 'minimal'],
      sections: ['pricing', 'faq'],
    },
    imageCount: 1,
    coverImage: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="480" height="300" viewBox="0 0 480 300"%3E%3Crect width="480" height="300" fill="%23F8FAFC"/%3E%3Crect x="140" y="100" width="200" height="100" rx="12" fill="%23FFFFFF" stroke="%23E2E8F0" stroke-width="2"/%3E%3Ccircle cx="180" cy="150" r="16" fill="%23047857"/%3E%3Ctext x="240" y="250" font-family="sans-serif" font-size="16" fill="%230F172A" text-anchor="middle"%3ENorthfield Fintech%3C/text%3E%3C/svg%3E',
    deviceId: 'system',
    createdAt: Date.now() - 86400000 * 10,
    copyCount: 64,
    visibility: 'public',
    publicAt: Date.now() - 86400000 * 10,
    publicCopyCount: 64,
  },
];

function loadLocalShares(): Map<string, ShareDoc & { id: string }> {
  const map = new Map<string, ShareDoc & { id: string }>();
  for (const item of initialCuratedShares) {
    map.set(item.id, item);
  }
  if (typeof localStorage !== 'undefined') {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SHARES);
      if (saved) {
        const parsed: (ShareDoc & { id: string })[] = JSON.parse(saved);
        for (const item of parsed) {
          map.set(item.id, item);
        }
      }
    } catch (e) {
      console.warn('Failed to parse shares from storage:', e);
    }
  }
  return map;
}

function persistLocalShares(map: Map<string, ShareDoc & { id: string }>) {
  if (typeof localStorage !== 'undefined') {
    try {
      localStorage.setItem(STORAGE_KEY_SHARES, JSON.stringify(Array.from(map.values())));
    } catch (e) {
      console.warn('Failed to persist shares:', e);
    }
  }
}

function loadLocalShareImages(): Map<string, ShareImageDoc[]> {
  const map = new Map<string, ShareImageDoc[]>();
  if (typeof localStorage !== 'undefined') {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_IMAGES);
      if (saved) {
        const parsed: Record<string, ShareImageDoc[]> = JSON.parse(saved);
        for (const [k, v] of Object.entries(parsed)) {
          map.set(k, v);
        }
      }
    } catch (e) {
      console.warn('Failed to parse share images:', e);
    }
  }
  return map;
}

function persistLocalShareImages(map: Map<string, ShareImageDoc[]>) {
  if (typeof localStorage !== 'undefined') {
    try {
      const obj: Record<string, ShareImageDoc[]> = {};
      for (const [k, v] of map.entries()) {
        obj[k] = v;
      }
      localStorage.setItem(STORAGE_KEY_IMAGES, JSON.stringify(obj));
    } catch (e) {
      console.warn('Failed to persist share images:', e);
    }
  }
}

const sharesMap = loadLocalShares();
const shareImagesMap = loadLocalShareImages();

export async function createShare(
  result: Result,
  coverImage: string,
  images: ResultImage[]
): Promise<string> {
  const shareId = nanoid(12);
  const deviceId = await getDeviceId();

  const shareDoc: ShareDoc & { id: string } = {
    id: shareId,
    title: result.title || 'Untitled Design Spec',
    markdown: result.markdown,
    tags: result.tags,
    imageCount: images.length,
    coverImage: coverImage || images[0]?.thumbDataUrl || '',
    deviceId,
    createdAt: Date.now(),
    copyCount: 0,
    visibility: 'unlisted',
  };

  sharesMap.set(shareId, shareDoc);
  persistLocalShares(sharesMap);

  const imageDocs: ShareImageDoc[] = images.map((img, i) => ({
    index: i,
    mime: 'image/jpeg',
    width: img.width,
    height: img.height,
    dataUrl: img.dataUrl || img.thumbDataUrl,
  }));

  shareImagesMap.set(shareId, imageDocs);
  persistLocalShareImages(shareImagesMap);

  return shareId;
}

export async function setPublic(shareId: string, isPublic: boolean): Promise<void> {
  const doc = sharesMap.get(shareId);
  if (!doc) throw new Error('Share document not found');

  if (isPublic) {
    doc.visibility = 'public';
    doc.publicAt = Date.now();
    doc.publicCopyCount = doc.copyCount;
  } else {
    doc.visibility = 'unlisted';
    delete doc.publicAt;
    delete doc.publicCopyCount;
  }

  sharesMap.set(shareId, doc);
  persistLocalShares(sharesMap);
}

export async function getShare(shareId: string): Promise<{ doc: ShareDoc; images: ShareImageDoc[] } | null> {
  const doc = sharesMap.get(shareId);
  if (!doc) return null;

  let images = shareImagesMap.get(shareId);
  if (!images || images.length === 0) {
    images = [
      {
        index: 0,
        mime: 'image/jpeg',
        width: 1200,
        height: 800,
        dataUrl: doc.coverImage,
      },
    ];
  }

  return { doc, images };
}

export async function incrementCopy(shareId: string): Promise<void> {
  const doc = sharesMap.get(shareId);
  if (!doc) return;

  doc.copyCount = (doc.copyCount || 0) + 1;
  if (doc.visibility === 'public') {
    doc.publicCopyCount = (doc.publicCopyCount || 0) + 1;
  }
  sharesMap.set(shareId, doc);
  persistLocalShares(sharesMap);
}

export interface ListPublicParams {
  sort?: 'new' | 'copied';
  pageSize?: number;
  cursor?: number;
}

export async function listPublic(params: ListPublicParams = {}): Promise<{
  items: (ShareDoc & { id: string })[];
  hasMore: boolean;
}> {
  const { sort = 'new', pageSize = 48, cursor = 0 } = params;

  let publicItems = Array.from(sharesMap.values()).filter(
    (item) => item.visibility === 'public'
  );

  if (sort === 'copied') {
    publicItems.sort((a, b) => (b.publicCopyCount || b.copyCount || 0) - (a.publicCopyCount || a.copyCount || 0));
  } else {
    publicItems.sort((a, b) => {
      const timeA = typeof a.publicAt === 'number' ? a.publicAt : typeof a.createdAt === 'number' ? a.createdAt : 0;
      const timeB = typeof b.publicAt === 'number' ? b.publicAt : typeof b.createdAt === 'number' ? b.createdAt : 0;
      return timeB - timeA;
    });
  }

  const paged = publicItems.slice(cursor, cursor + pageSize);
  const hasMore = cursor + pageSize < publicItems.length;

  return {
    items: paged,
    hasMore,
  };
}
