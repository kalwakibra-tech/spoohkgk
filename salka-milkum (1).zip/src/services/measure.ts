/**
 * Image palette and geometry measurement
 * Document 2, Section 5.1 & 5.3
 */
import { Measurements } from '../types';
import { COLOR_SNAP_DISTANCE, COLOR_MERGE_DISTANCE } from '../config';

interface ImageInput {
  width: number;
  height: number;
  dataUrl: string;
}

function hexFromRgb(r: number, g: number, b: number): string {
  const toHex = (n: number) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, '0').toUpperCase();
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

function colorDistance(r1: number, g1: number, b1: number, r2: number, g2: number, b2: number): number {
  return Math.sqrt((r1 - r2) ** 2 + (g1 - g2) ** 2 + (b1 - b2) ** 2);
}

function parseHex(hex: string): { r: number; g: number; b: number } {
  const h = hex.replace('#', '');
  return {
    r: parseInt(h.substring(0, 2), 16) || 0,
    g: parseInt(h.substring(2, 4), 16) || 0,
    b: parseInt(h.substring(4, 6), 16) || 0,
  };
}

export async function measureImages(images: ImageInput[]): Promise<Measurements> {
  const dimensions = images.map((img) => ({
    width: img.width,
    height: img.height,
    aspectRatio: img.height > 0 ? parseFloat((img.width / img.height).toFixed(3)) : 1,
  }));

  const colorBuckets = new Map<string, number>();
  let totalPixelsSampled = 0;

  for (const img of images) {
    if (!img.dataUrl) continue;

    await new Promise<void>((resolve) => {
      const el = new Image();
      el.crossOrigin = 'anonymous';
      el.onload = () => {
        const sampleSide = 120;
        const canvas = document.createElement('canvas');
        canvas.width = sampleSide;
        canvas.height = sampleSide;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve();
          return;
        }

        ctx.drawImage(el, 0, 0, sampleSide, sampleSide);
        const data = ctx.getImageData(0, 0, sampleSide, sampleSide).data;
        const pixelCount = sampleSide * sampleSide;

        for (let i = 0; i < pixelCount; i++) {
          const idx = i * 4;
          const a = data[idx + 3];
          if (a < 128) continue; // Skip transparent pixels

          // Quantize to 5 bits per channel (step of 8)
          const r = Math.round(data[idx] / 8) * 8;
          const g = Math.round(data[idx + 1] / 8) * 8;
          const b = Math.round(data[idx + 2] / 8) * 8;

          const hex = hexFromRgb(r, g, b);
          colorBuckets.set(hex, (colorBuckets.get(hex) || 0) + 1);
          totalPixelsSampled++;
        }
        resolve();
      };
      el.onerror = () => resolve();
      el.src = img.dataUrl;
    });
  }

  // Sort raw colors by frequency
  const sortedColors = Array.from(colorBuckets.entries())
    .map(([hex, count]) => ({ hex, count }))
    .sort((a, b) => b.count - a.count);

  // Cluster and merge visually close colors
  const mergedPalette: { hex: string; count: number }[] = [];

  for (const item of sortedColors) {
    const { r, g, b } = parseHex(item.hex);
    let matched = false;

    for (const existing of mergedPalette) {
      const ex = parseHex(existing.hex);
      if (colorDistance(r, g, b, ex.r, ex.g, ex.b) < COLOR_MERGE_DISTANCE) {
        existing.count += item.count;
        matched = true;
        break;
      }
    }

    if (!matched) {
      mergedPalette.push({ hex: item.hex, count: item.count });
    }
  }

  // Take top 8 dominant colors
  const topMerged = mergedPalette
    .sort((a, b) => b.count - a.count)
    .slice(0, 8);

  const palette = topMerged.map((c, index) => {
    const percentage = totalPixelsSampled > 0
      ? parseFloat(((c.count / totalPixelsSampled) * 100).toFixed(1))
      : 0;

    let role = 'accent';
    if (index === 0) role = 'background';
    else if (index === 1) role = 'surface';
    else if (index === 2) role = 'primary';
    else if (index === 3) role = 'text';

    return {
      hex: c.hex,
      role,
      percentage,
    };
  });

  return {
    palette,
    dimensions,
  };
}
