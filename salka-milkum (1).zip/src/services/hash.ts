/**
 * SHA-256 file hashing for deterministic caching
 * Document 2, Section 5.1 & 5.4
 */

export async function computeFilesHash(files: File[]): Promise<string> {
  const fileBuffers = await Promise.all(
    files.map(async (file) => {
      const buffer = await file.arrayBuffer();
      const meta = `${file.name}:${file.size}:${file.type}:`;
      const metaBuffer = new TextEncoder().encode(meta);
      const combined = new Uint8Array(metaBuffer.byteLength + buffer.byteLength);
      combined.set(metaBuffer, 0);
      combined.set(new Uint8Array(buffer), metaBuffer.byteLength);
      return combined;
    })
  );

  const totalLength = fileBuffers.reduce((sum, b) => sum + b.byteLength, 0);
  const allData = new Uint8Array(totalLength);
  let offset = 0;
  for (const buf of fileBuffers) {
    allData.set(buf, offset);
    offset += buf.byteLength;
  }

  // Use Web Crypto API
  if (typeof crypto !== 'undefined' && crypto.subtle) {
    const digest = await crypto.subtle.digest('SHA-256', allData);
    return Array.from(new Uint8Array(digest))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
  }

  // Fallback hash
  let h1 = 0xdeadbeef, h2 = 0x41c64e6d;
  for (let i = 0; i < allData.length; i++) {
    const ch = allData[i];
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507);
  h1 ^= Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507);
  h2 ^= Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
}

export function makeCacheKey(hash: string): string {
  return `v1_${hash}`;
}
