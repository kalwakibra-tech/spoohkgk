/**
 * Pipeline orchestrator
 * Document 2, Section 5.4
 */
import { nanoid } from 'nanoid';
import { MAX_FILES } from '../config';
import { AppError, getErrorMessage } from './errors';
import { computeFilesHash, makeCacheKey } from './hash';
import { processUploadFile, PreparedImage } from './prepare';
import { measureImages } from './measure';
import { callAiAnalyze, callAiExtract } from './ai';
import { renderDesignMd } from './render';
import { saveResult, getCachedResultId, getResult, setSiteQueue } from '../storage/local';
import { PipelineEvent, PipelineOptions, SiteGroup, Result, ResultImage } from '../types';

export async function runPipeline(files: File[], opts: PipelineOptions): Promise<void> {
  const { signal, onEvent, requestChoice } = opts;

  try {
    if (signal.aborted) throw new AppError('cancelled');

    // ----------------------------------------------------
    // STEP 1: CHECK (hash, validate client rules, prepare)
    // ----------------------------------------------------
    onEvent({ type: 'step', step: 'check', status: 'active' });

    if (files.length === 0) {
      throw new AppError('network', 'No files provided.');
    }

    if (files.length > MAX_FILES) {
      onEvent({
        type: 'rejected',
        items: files.slice(MAX_FILES).map(f => ({
          fileName: f.name,
          code: 'too_many_files',
        })),
      });
      return;
    }

    // Process and validate files
    const preparedList: PreparedImage[] = [];
    const clientRejectedItems: { fileName: string; code: string; reason?: string }[] = [];

    for (const file of files) {
      if (signal.aborted) throw new AppError('cancelled');
      const prepared = await processUploadFile(file);
      if (prepared.issueCode) {
        clientRejectedItems.push({
          fileName: file.name,
          code: prepared.issueCode,
          reason: prepared.issueReason || getErrorMessage(prepared.issueCode),
        });
      }
      preparedList.push(prepared);
    }

    if (clientRejectedItems.length > 0) {
      onEvent({ type: 'rejected', items: clientRejectedItems });
      return;
    }

    // Compute deterministic cache key from input file contents
    const hash = await computeFilesHash(files);
    const cacheKey = makeCacheKey(hash);

    // Check IndexedDB cache
    const cachedId = await getCachedResultId(cacheKey);
    if (cachedId) {
      const existing = await getResult(cachedId);
      if (existing) {
        onEvent({ type: 'step', step: 'check', status: 'done' });
        onEvent({ type: 'cache_hit', resultId: cachedId });
        onEvent({ type: 'done', resultIds: [cachedId] });
        return;
      }
    }

    onEvent({ type: 'step', step: 'check', status: 'done' });

    // ----------------------------------------------------
    // STEP 2: MEASURE (palette and layout geometry)
    // ----------------------------------------------------
    if (signal.aborted) throw new AppError('cancelled');
    onEvent({ type: 'step', step: 'measure', status: 'active' });

    const measurements = await measureImages(
      preparedList.map(p => ({
        width: p.width,
        height: p.height,
        dataUrl: p.dataUrl,
      }))
    );

    onEvent({ type: 'step', step: 'measure', status: 'done' });

    // ----------------------------------------------------
    // STEP 3: ANALYZE (verify website, multi-site detection)
    // ----------------------------------------------------
    if (signal.aborted) throw new AppError('cancelled');
    onEvent({ type: 'step', step: 'analyze', status: 'active' });

    const analyzeResult = await callAiAnalyze(
      preparedList.map(p => ({
        base64: p.aiBase64,
        mimeType: 'image/jpeg',
      })),
      signal,
      (inSeconds, attempt) => {
        onEvent({ type: 'retry', inSeconds, attempt });
      }
    );

    if (!analyzeResult.isWebsite) {
      const code = analyzeResult.rejectionCode || 'not_website';
      const reason = analyzeResult.rejectionReason || getErrorMessage(code);
      onEvent({
        type: 'rejected',
        items: files.map(f => ({ fileName: f.name, code, reason })),
      });
      return;
    }

    let sitesToProcess: SiteGroup[] = [];
    if (analyzeResult.sites.length > 1) {
      // Prompt user to choose
      const choice = await requestChoice(analyzeResult.sites);
      const chosenSiteIds = choice.siteIds;

      sitesToProcess = analyzeResult.sites.filter(s => chosenSiteIds.includes(s.id));
      const unchosenSites = analyzeResult.sites.filter(s => !chosenSiteIds.includes(s.id));

      if (unchosenSites.length > 0) {
        // Save remaining sites to siteQueue in local meta store
        await setSiteQueue(unchosenSites);
      } else {
        await setSiteQueue([]);
      }
    } else if (analyzeResult.sites.length === 1) {
      sitesToProcess = analyzeResult.sites;
      await setSiteQueue([]);
    } else {
      // Default to single site encompassing all images
      sitesToProcess = [
        {
          id: 'site-1',
          label: 'Website Screenshot',
          description: 'Single site extraction',
          sections: ['hero', 'features'],
          imageIndices: preparedList.map((_, i) => i),
        },
      ];
      await setSiteQueue([]);
    }

    onEvent({ type: 'step', step: 'analyze', status: 'done' });

    // ----------------------------------------------------
    // STEP 4: EXTRACT (Extract tokens & components)
    // ----------------------------------------------------
    if (signal.aborted) throw new AppError('cancelled');
    onEvent({ type: 'step', step: 'extract', status: 'active' });

    const createdResultIds: string[] = [];

    for (const site of sitesToProcess) {
      if (signal.aborted) throw new AppError('cancelled');

      // Select images for this site
      const siteImages = (site.imageIndices || [0])
        .filter(idx => idx >= 0 && idx < preparedList.length)
        .map(idx => preparedList[idx]);

      const effectiveImages = siteImages.length > 0 ? siteImages : preparedList;

      const spec = await callAiExtract(
        effectiveImages.map(p => ({
          base64: p.aiBase64,
          mimeType: 'image/jpeg',
        })),
        measurements,
        signal,
        (inSeconds, attempt) => {
          onEvent({ type: 'retry', inSeconds, attempt });
        }
      );

      // Overwrite meta title if site label is specific
      if (site.label && site.label !== 'Untitled Site') {
        spec.meta.title = site.label.slice(0, 60);
      }

      onEvent({ type: 'step', step: 'extract', status: 'done' });

      // ----------------------------------------------------
      // STEP 5: VALIDATE & RENDER (Render design.md & Save)
      // ----------------------------------------------------
      if (signal.aborted) throw new AppError('cancelled');
      onEvent({ type: 'step', step: 'validate', status: 'active' });

      const markdown = renderDesignMd(spec);

      const resultImages: ResultImage[] = effectiveImages.map(p => ({
        name: p.file.name,
        width: p.width,
        height: p.height,
        thumbDataUrl: p.thumbDataUrl,
        dataUrl: p.dataUrl,
      }));

      const newId = nanoid(10);
      const resultObj: Result = {
        id: newId,
        createdAt: Date.now(),
        cacheKey: sitesToProcess.length === 1 ? cacheKey : `${cacheKey}_${site.id}`,
        title: spec.meta.title,
        tags: {
          industry: [spec.meta.industry],
          style: spec.meta.styleTags,
          sections: spec.meta.sections,
        },
        markdown,
        spec,
        images: resultImages,
      };

      await saveResult(resultObj);
      createdResultIds.push(newId);
    }

    onEvent({ type: 'step', step: 'validate', status: 'done' });
    onEvent({ type: 'done', resultIds: createdResultIds });
  } catch (err: any) {
    if (signal.aborted || err?.code === 'cancelled' || err?.message === 'cancelled') {
      onEvent({ type: 'error', error: new AppError('cancelled') });
    } else {
      onEvent({ type: 'error', error: err instanceof AppError ? err : new AppError('network', err?.message) });
    }
  }
}
