/**
 * Image preparation, decoding, resizing, and quality validation
 * Document 2, Section 5.1 & 5.3
 */
import {
  MAX_FILE_MB,
  MIN_WIDTH,
  MIN_HEIGHT,
  MAX_DIM,
  AI_MAX_SIDE,
  AI_JPEG_QUALITY,
} from '../config';
import { getErrorMessage } from './errors';

export interface PreparedImage {
  file: File;
  width: number;
  height: number;
  dataUrl: string;
  thumbDataUrl: string;
  aiBase64: string;
  issueCode?: string;
  issueReason?: string;
}

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Failed to load image'));
    img.src = src;
  });
}

/**
 * Computes variance of the Laplacian over a grayscale 512px canvas copy to detect blur
 */
function calculateLaplacianBlurScore(canvas: HTMLCanvasElement): number {
  const ctx = canvas.getContext('2d');
  if (!ctx) return 100;

  const w = canvas.width;
  const h = canvas.height;
  const imgData = ctx.getImageData(0, 0, w, h);
  const data = imgData.data;

  // Compute grayscale
  const gray = new Float32Array(w * h);
  for (let i = 0; i < w * h; i++) {
    const idx = i * 4;
    gray[i] = 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2];
  }

  // Apply Laplacian filter
  let sum = 0;
  let sumSq = 0;
  let count = 0;

  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const idx = y * w + x;
      const lap =
        gray[idx - w] +
        gray[idx - 1] - 4 * gray[idx] +
        gray[idx + 1] +
        gray[idx + w];

      sum += lap;
      sumSq += lap * lap;
      count++;
    }
  }

  if (count === 0) return 100;
  const mean = sum / count;
  const variance = sumSq / count - mean * mean;
  return variance;
}

export async function processUploadFile(file: File): Promise<PreparedImage> {
  // File size check
  if (file.size > MAX_FILE_MB * 1024 * 1024) {
    return {
      file,
      width: 0,
      height: 0,
      dataUrl: '',
      thumbDataUrl: '',
      aiBase64: '',
      issueCode: 'too_large',
      issueReason: getErrorMessage('too_large'),
    };
  }

  try {
    const dataUrl = await readFileAsDataUrl(file);
    const img = await loadImage(dataUrl);
    const width = img.naturalWidth || img.width;
    const height = img.naturalHeight || img.height;

    // Dimension checks
    if (width < MIN_WIDTH || height < MIN_HEIGHT) {
      return {
        file,
        width,
        height,
        dataUrl,
        thumbDataUrl: dataUrl,
        aiBase64: '',
        issueCode: 'too_small',
        issueReason: `Dimensions (${width}×${height}) are too small (minimum ${MIN_WIDTH}×${MIN_HEIGHT}).`,
      };
    }

    if (width > MAX_DIM || height > MAX_DIM) {
      return {
        file,
        width,
        height,
        dataUrl,
        thumbDataUrl: dataUrl,
        aiBase64: '',
        issueCode: 'too_large',
        issueReason: `Dimensions (${width}×${height}) exceed the maximum allowed ${MAX_DIM}px.`,
      };
    }

    // Blur check on 512px canvas
    const blurCanvas = document.createElement('canvas');
    const blurSide = 512;
    const blurScale = Math.min(blurSide / width, blurSide / height, 1);
    blurCanvas.width = Math.max(1, Math.round(width * blurScale));
    blurCanvas.height = Math.max(1, Math.round(height * blurScale));
    const blurCtx = blurCanvas.getContext('2d');
    if (blurCtx) {
      blurCtx.drawImage(img, 0, 0, blurCanvas.width, blurCanvas.height);
      const blurScore = calculateLaplacianBlurScore(blurCanvas);
      // Extremely low variance indicates completely blurry or flat image
      if (blurScore < 1.0) {
        return {
          file,
          width,
          height,
          dataUrl,
          thumbDataUrl: dataUrl,
          aiBase64: '',
          issueCode: 'blurry',
          issueReason: getErrorMessage('blurry'),
        };
      }
    }

    // Create thumbnail (max 320px)
    const thumbCanvas = document.createElement('canvas');
    const thumbMax = 320;
    const thumbScale = Math.min(thumbMax / width, thumbMax / height, 1);
    thumbCanvas.width = Math.max(1, Math.round(width * thumbScale));
    thumbCanvas.height = Math.max(1, Math.round(height * thumbScale));
    const thumbCtx = thumbCanvas.getContext('2d');
    let thumbDataUrl = dataUrl;
    if (thumbCtx) {
      thumbCtx.drawImage(img, 0, 0, thumbCanvas.width, thumbCanvas.height);
      thumbDataUrl = thumbCanvas.toDataURL('image/jpeg', 0.85);
    }

    // Create AI payload resized to AI_MAX_SIDE with AI_JPEG_QUALITY
    const aiCanvas = document.createElement('canvas');
    const aiScale = Math.min(AI_MAX_SIDE / width, AI_MAX_SIDE / height, 1);
    aiCanvas.width = Math.max(1, Math.round(width * aiScale));
    aiCanvas.height = Math.max(1, Math.round(height * aiScale));
    const aiCtx = aiCanvas.getContext('2d');
    let aiBase64 = '';
    if (aiCtx) {
      aiCtx.drawImage(img, 0, 0, aiCanvas.width, aiCanvas.height);
      const aiDataUrl = aiCanvas.toDataURL('image/jpeg', AI_JPEG_QUALITY);
      aiBase64 = aiDataUrl.replace(/^data:image\/[a-z]+;base64,/, '');
    } else {
      aiBase64 = dataUrl.replace(/^data:image\/[a-z]+;base64,/, '');
    }

    return {
      file,
      width,
      height,
      dataUrl,
      thumbDataUrl,
      aiBase64,
    };
  } catch (err: any) {
    return {
      file,
      width: 0,
      height: 0,
      dataUrl: '',
      thumbDataUrl: '',
      aiBase64: '',
      issueCode: 'unreadable',
      issueReason: getErrorMessage('unreadable'),
    };
  }
}
