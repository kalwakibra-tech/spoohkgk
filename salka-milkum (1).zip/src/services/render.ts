/**
 * DesignSpec to design.md Markdown renderer
 * Document 2, Section 5.8 & 5.9
 */
import { DesignSpec } from '../types';

export function slug(text: string): string {
  if (!text) return 'untitled';
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function esc(text: string | number | undefined | null): string {
  if (text === undefined || text === null) return '—';
  const str = String(text).replace(/\|/g, '\\|').replace(/\r?\n/g, ' ').trim();
  return str.length > 0 ? str : '—';
}

function formatHex(v: string | undefined): string {
  if (!v) return '—';
  const clean = v.trim();
  if (clean.startsWith('#')) {
    return `\`${clean.toUpperCase()}\``;
  }
  return `\`${clean}\``;
}

function formatPx(val: string | number | undefined): string {
  if (val === undefined || val === null || val === '') return '—';
  const s = String(val).trim();
  if (s.endsWith('px') || s.endsWith('rem') || s.endsWith('em') || s.endsWith('%')) {
    return s;
  }
  const n = Number(s);
  return isNaN(n) ? s : `${Math.round(n)}px`;
}

export function renderDesignMd(spec: DesignSpec): string {
  const lines: string[] = [];

  // Title and header
  lines.push(`# ${spec.meta.title || 'Untitled'} — Style Reference`);
  if (spec.meta.summary) {
    lines.push(`> ${spec.meta.summary}`);
  }
  lines.push('');
  lines.push(`**Theme:** ${spec.meta.theme || 'dark'}`);
  lines.push('');
  lines.push('Source measurements are normalized; roles and recommendations are interpreted. Font summary lists are independent, not paired by position. HTML examples are reconstructions, not source components.');
  lines.push('');
  if (spec.meta.description) {
    lines.push(spec.meta.description);
    lines.push('');
  }

  // --------------------------------------------------------------------------
  // Colors
  // --------------------------------------------------------------------------
  lines.push('## Tokens — Colors');
  lines.push('');
  lines.push('| Name | Value | Token | Role |');
  lines.push('|------|-------|-------|------|');
  for (const c of spec.colors || []) {
    lines.push(`| ${esc(c.name)} | ${formatHex(c.value)} | \`${esc(c.token)}\` | ${esc(c.role)} |`);
  }
  lines.push('');

  // --------------------------------------------------------------------------
  // Typography
  // --------------------------------------------------------------------------
  lines.push('## Tokens — Typography');
  lines.push('');

  const fonts = [spec.typography.primaryFont, spec.typography.secondaryFont, spec.typography.utilityFont].filter(Boolean);

  for (const font of fonts) {
    if (!font) continue;
    const fontSlug = slug(font.name);
    lines.push(`### ${esc(font.name)} — ${esc(font.role)} · \`--font-${fontSlug}\``);
    if (font.substitute) {
      lines.push(`- **Substitute:** ${esc(font.substitute)}`);
    }
    if (font.weights && font.weights.length > 0) {
      lines.push(`- **Weights:** ${font.weights.join(', ')}`);
    }
    if (font.sizes && font.sizes.length > 0) {
      lines.push(`- **Sizes:** ${font.sizes.map(s => formatPx(s)).join(', ')}`);
    }
    if (font.lineHeight) {
      lines.push(`- **Line height:** ${esc(font.lineHeight)}`);
    }
    if (font.letterSpacing) {
      lines.push(`- **Letter spacing:** ${esc(font.letterSpacing)}`);
    }
    if (font.role) {
      lines.push(`- **Role:** ${esc(font.role)}`);
    }
    lines.push('');
  }

  // Type Scale Table
  if (spec.typography.typeScale && spec.typography.typeScale.length > 0) {
    lines.push('### Type Scale');
    lines.push('');
    lines.push('| Role | Family | Weight | Size | Line Height | Letter Spacing | Token |');
    lines.push('|------|--------|--------|------|-------------|----------------|-------|');
    for (const item of spec.typography.typeScale) {
      lines.push(
        `| ${esc(item.role)} | ${esc(item.family)} | ${esc(item.weight)} | ${formatPx(item.size)} | ${esc(item.lineHeight)} | ${esc(item.letterSpacing)} | \`${esc(item.token)}\` |`
      );
    }
    lines.push('');
  }

  // --------------------------------------------------------------------------
  // Spacing & Shapes
  // --------------------------------------------------------------------------
  lines.push('## Tokens — Spacing & Shapes');
  lines.push('');
  lines.push(`**Base unit:** ${spec.spacing.baseUnit || 4}px`);
  lines.push('');
  lines.push(`**Density:** ${spec.spacing.density || 'comfortable'}`);
  lines.push('');

  if (spec.spacing.scale && spec.spacing.scale.length > 0) {
    lines.push('### Spacing Scale');
    lines.push('');
    lines.push('| Name | Value | Token |');
    lines.push('|------|-------|-------|');
    for (const s of spec.spacing.scale) {
      lines.push(`| ${esc(s.name)} | ${formatPx(s.value)} | \`${esc(s.token)}\` |`);
    }
    lines.push('');
  }

  if (spec.spacing.radii && spec.spacing.radii.length > 0) {
    lines.push('### Border Radius');
    lines.push('');
    lines.push('| Element | Value | Token |');
    lines.push('|---------|-------|-------|');
    for (const r of spec.spacing.radii) {
      lines.push(`| ${esc(r.element)} | ${formatPx(r.value)} | \`${esc(r.token || `--radius-${slug(r.element)}`)}\` |`);
    }
    lines.push('');
  }

  if (spec.spacing.shadows && spec.spacing.shadows.length > 0) {
    lines.push('### Shadows');
    lines.push('');
    lines.push('| Name | Value | Token |');
    lines.push('|------|-------|-------|');
    for (const sh of spec.spacing.shadows) {
      lines.push(`| ${esc(sh.name)} | ${esc(sh.value)} | \`${esc(sh.token)}\` |`);
    }
    lines.push('');
  }

  if (spec.spacing.layout) {
    lines.push('### Layout');
    lines.push('');
    lines.push(`- **Max Width:** ${esc(spec.spacing.layout.pageMaxWidth)}`);
    lines.push(`- **Section Gap:** ${esc(spec.spacing.layout.sectionGap)}`);
    lines.push(`- **Card Padding:** ${esc(spec.spacing.layout.cardPadding)}`);
    lines.push(`- **Element Gap:** ${esc(spec.spacing.layout.elementGap)}`);
    lines.push('');
  }

  // --------------------------------------------------------------------------
  // Surfaces
  // --------------------------------------------------------------------------
  if (spec.surfaces && spec.surfaces.length > 0) {
    lines.push('## Surfaces');
    lines.push('');
    lines.push('| Level | Name | Value | Purpose |');
    lines.push('|-------|------|-------|---------|');
    for (const surf of spec.surfaces) {
      lines.push(`| ${esc(surf.level)} | ${esc(surf.name)} | ${formatHex(surf.value)} | ${esc(surf.purpose)} |`);
    }
    lines.push('');
  }

  // --------------------------------------------------------------------------
  // Components
  // --------------------------------------------------------------------------
  if (spec.components && spec.components.length > 0) {
    lines.push('## Components');
    lines.push('');
    for (const comp of spec.components) {
      lines.push(`### ${esc(comp.name)}`);
      lines.push(`**Role:** ${esc(comp.role)}`);
      lines.push('');
      lines.push(esc(comp.description));
      lines.push('');
      if (comp.tokensUsed && comp.tokensUsed.length > 0) {
        lines.push(`- **Tokens:** ${comp.tokensUsed.map(t => `\`${t}\``).join(', ')}`);
        lines.push('');
      }
    }
  }

  // --------------------------------------------------------------------------
  // Do's and Don'ts
  // --------------------------------------------------------------------------
  if (spec.dosAndDonts) {
    lines.push("## Do's and Don'ts");
    lines.push('');
    if (spec.dosAndDonts.dos && spec.dosAndDonts.dos.length > 0) {
      lines.push('### Do');
      for (const d of spec.dosAndDonts.dos) {
        lines.push(`- ${esc(d)}`);
      }
      lines.push('');
    }
    if (spec.dosAndDonts.donts && spec.dosAndDonts.donts.length > 0) {
      lines.push("### Don't");
      for (const d of spec.dosAndDonts.donts) {
        lines.push(`- ${esc(d)}`);
      }
      lines.push('');
    }
  }

  return lines.join('\n');
}
