/**
 * Zod validation schemas and normalization for AnalyzeResult and DesignSpec
 * Document 2, Section 5.1 & Document 1, Section 8
 */
import { z } from 'zod';
import { AnalyzeResult, DesignSpec } from '../types';

export const SiteGroupSchema = z.object({
  id: z.string().default('site-1'),
  label: z.string().default('Untitled Site'),
  description: z.string().default(''),
  sections: z.array(z.string()).default([]),
  imageIndices: z.array(z.number()).default([0]),
});

export const AnalyzeResultSchema = z.object({
  isWebsite: z.boolean().default(true),
  rejectionCode: z.string().nullable().optional(),
  rejectionReason: z.string().nullable().optional(),
  sites: z.array(SiteGroupSchema).default([]),
});

export const ColorTokenSchema = z.object({
  name: z.string().default('Color'),
  value: z.string().default('#000000'),
  token: z.string().default('--color-custom'),
  role: z.string().default('Background or foreground color'),
});

export const TypeScaleItemSchema = z.object({
  role: z.string().default('body'),
  family: z.string().default('Inter'),
  weight: z.union([z.number(), z.string()]).default(400),
  size: z.union([z.number(), z.string()]).default('16px'),
  lineHeight: z.union([z.number(), z.string()]).default('1.5'),
  letterSpacing: z.union([z.number(), z.string()]).default('0em'),
  token: z.string().default('--text-body'),
});

export const TypefaceInfoSchema = z.object({
  name: z.string().default('Inter'),
  substitute: z.string().default('system-ui, sans-serif'),
  role: z.string().default('Primary typeface'),
  weights: z.array(z.union([z.number(), z.string()])).default([400, 600]),
  sizes: z.array(z.union([z.number(), z.string()])).default([14, 16, 24]),
  lineHeight: z.string().default('1.5'),
  letterSpacing: z.string().default('0em'),
  token: z.string().default('--font-primary'),
});

export const SpacingItemSchema = z.object({
  name: z.string().default('base'),
  value: z.string().default('16px'),
  token: z.string().default('--spacing-16'),
});

export const RadiusItemSchema = z.object({
  element: z.string().default('cards'),
  value: z.string().default('16px'),
  token: z.string().optional(),
});

export const ElevationItemSchema = z.object({
  name: z.string().default('subtle'),
  value: z.string().default('rgba(255, 255, 255, 0.12) 0px 0px 0px 1px inset'),
  token: z.string().default('--shadow-subtle'),
});

export const SurfaceItemSchema = z.object({
  level: z.number().default(0),
  name: z.string().default('Obsidian'),
  value: z.string().default('#000000'),
  purpose: z.string().default('Page canvas floor'),
});

export const ComponentSpecSchema = z.object({
  name: z.string().default('Component'),
  role: z.string().default('UI element'),
  description: z.string().default(''),
  props: z.record(z.string(), z.string()).optional(),
  tokensUsed: z.array(z.string()).optional(),
});

export const DesignSpecSchema = z.object({
  meta: z.object({
    title: z.string().max(60).default('Extracted Design System'),
    theme: z.enum(['dark', 'light', 'mixed']).default('dark'),
    industry: z.string().default('ai-tech'),
    styleTags: z.array(z.string()).default(['dark', 'minimal']),
    sections: z.array(z.string()).default(['hero', 'features']),
    summary: z.string().default('Production-grade web interface design system.'),
    description: z.string().default('Extracted design tokens and component specifications.'),
  }),
  colors: z.array(ColorTokenSchema).default([]),
  typography: z.object({
    primaryFont: TypefaceInfoSchema.default({
      name: 'Inter',
      substitute: 'system-ui, sans-serif',
      role: 'Primary brand typeface',
      weights: [400, 600],
      sizes: [14, 16, 24],
      lineHeight: '1.5',
      letterSpacing: '-0.01em',
      token: '--font-primary',
    }),
    secondaryFont: TypefaceInfoSchema.optional(),
    utilityFont: TypefaceInfoSchema.optional(),
    typeScale: z.array(TypeScaleItemSchema).default([]),
  }),
  spacing: z.object({
    baseUnit: z.number().default(4),
    density: z.string().default('comfortable'),
    scale: z.array(SpacingItemSchema).default([]),
    radii: z.array(RadiusItemSchema).default([]),
    shadows: z.array(ElevationItemSchema).default([]),
    layout: z.object({
      pageMaxWidth: z.string().default('1200px'),
      sectionGap: z.string().default('80px'),
      cardPadding: z.string().default('24px'),
      elementGap: z.string().default('20px'),
    }),
  }),
  surfaces: z.array(SurfaceItemSchema).default([]),
  components: z.array(ComponentSpecSchema).default([]),
  dosAndDonts: z.object({
    dos: z.array(z.string()).default([]),
    donts: z.array(z.string()).default([]),
  }),
});

export function normalizeDesignSpec(spec: DesignSpec): DesignSpec {
  // Normalize colors to uppercase hex
  spec.colors = spec.colors.map(c => {
    let val = c.value.trim();
    if (val.startsWith('#')) {
      val = val.toUpperCase();
    }
    return { ...c, value: val };
  });

  // Normalize surfaces to uppercase hex
  spec.surfaces = spec.surfaces.map(s => {
    let val = s.value.trim();
    if (val.startsWith('#')) {
      val = val.toUpperCase();
    }
    return { ...s, value: val };
  });

  // Ensure title is trimmed to 60 chars max
  spec.meta.title = spec.meta.title.trim().slice(0, 60);

  return spec;
}

export function sanitizeSpecData(data: any): any {
  if (!data || typeof data !== 'object') {
    data = {};
  }
  const obj = { ...data };

  // Ensure meta
  obj.meta = { ...obj.meta };
  obj.meta.title = typeof obj.meta.title === 'string' && obj.meta.title.trim() ? obj.meta.title.trim().slice(0, 60) : 'Extracted Design System';
  const rawTheme = String(obj.meta.theme || 'dark').toLowerCase();
  obj.meta.theme = ['light', 'dark', 'mixed'].includes(rawTheme) ? rawTheme : 'dark';
  obj.meta.industry = typeof obj.meta.industry === 'string' && obj.meta.industry ? obj.meta.industry : 'tech';
  obj.meta.styleTags = Array.isArray(obj.meta.styleTags) && obj.meta.styleTags.length > 0 ? obj.meta.styleTags : ['dark', 'minimal'];
  obj.meta.sections = Array.isArray(obj.meta.sections) && obj.meta.sections.length > 0 ? obj.meta.sections : ['hero', 'features'];
  obj.meta.summary = typeof obj.meta.summary === 'string' && obj.meta.summary ? obj.meta.summary : 'Extracted web design system.';
  obj.meta.description = typeof obj.meta.description === 'string' && obj.meta.description ? obj.meta.description : 'Precision design specifications extracted from interface screenshots.';

  // Ensure colors is array
  if (!Array.isArray(obj.colors)) {
    obj.colors = [];
  } else {
    obj.colors = obj.colors.map((c: any, idx: number) => ({
      name: typeof c?.name === 'string' && c.name ? c.name : `Color ${idx + 1}`,
      value: typeof c?.value === 'string' && c.value ? (c.value.startsWith('#') ? c.value : `#${c.value}`) : '#000000',
      token: typeof c?.token === 'string' && c.token ? c.token : `--color-${idx + 1}`,
      role: typeof c?.role === 'string' && c.role ? c.role : 'UI color token',
    }));
  }

  // Ensure typography
  if (!obj.typography || typeof obj.typography !== 'object') {
    obj.typography = {
      primaryFont: {
        name: 'Inter',
        substitute: 'system-ui, -apple-system, sans-serif',
        role: 'Primary brand typeface',
        weights: [400, 600],
        sizes: [14, 16, 24],
        lineHeight: '1.5',
        letterSpacing: '-0.01em',
        token: '--font-primary',
      },
      typeScale: [],
    };
  } else {
    obj.typography = { ...obj.typography };
    if (!obj.typography.primaryFont || typeof obj.typography.primaryFont !== 'object') {
      obj.typography.primaryFont = {
        name: 'Inter',
        substitute: 'system-ui, -apple-system, sans-serif',
        role: 'Primary brand typeface',
        weights: [400, 600],
        sizes: [14, 16, 24],
        lineHeight: '1.5',
        letterSpacing: '-0.01em',
        token: '--font-primary',
      };
    }
    if (!Array.isArray(obj.typography.typeScale)) {
      obj.typography.typeScale = [];
    }
  }

  // Ensure spacing
  if (!obj.spacing || typeof obj.spacing !== 'object') {
    obj.spacing = {
      baseUnit: 4,
      density: 'comfortable',
      scale: [],
      radii: [],
      shadows: [],
      layout: {
        pageMaxWidth: '1200px',
        sectionGap: '80px',
        cardPadding: '24px',
        elementGap: '20px',
      },
    };
  } else {
    obj.spacing = { ...obj.spacing };
    obj.spacing.baseUnit = typeof obj.spacing.baseUnit === 'number' ? obj.spacing.baseUnit : 4;
    obj.spacing.density = typeof obj.spacing.density === 'string' ? obj.spacing.density : 'comfortable';
    if (!Array.isArray(obj.spacing.scale)) obj.spacing.scale = [];
    if (!Array.isArray(obj.spacing.radii)) obj.spacing.radii = [];
    if (!Array.isArray(obj.spacing.shadows)) obj.spacing.shadows = [];
    if (!obj.spacing.layout || typeof obj.spacing.layout !== 'object') {
      obj.spacing.layout = {
        pageMaxWidth: '1200px',
        sectionGap: '80px',
        cardPadding: '24px',
        elementGap: '20px',
      };
    }
  }

  // Ensure surfaces
  if (!Array.isArray(obj.surfaces)) {
    obj.surfaces = [];
  }

  // Ensure components
  if (!Array.isArray(obj.components)) {
    obj.components = [];
  }

  // Ensure dosAndDonts
  if (!obj.dosAndDonts || typeof obj.dosAndDonts !== 'object') {
    obj.dosAndDonts = {
      dos: ['Use tokenized colors and typography', 'Maintain consistent spacing hierarchy'],
      donts: ['Do not use unverified raw hex codes', 'Avoid mixing inconsistent button border radii'],
    };
  } else {
    obj.dosAndDonts = {
      dos: Array.isArray(obj.dosAndDonts.dos) ? obj.dosAndDonts.dos : [],
      donts: Array.isArray(obj.dosAndDonts.donts) ? obj.dosAndDonts.donts : [],
    };
  }

  return obj;
}

export function validateDesignSpec(data: unknown): { success: boolean; data?: DesignSpec; errors?: string[] } {
  const sanitized = sanitizeSpecData(data);
  const result = DesignSpecSchema.safeParse(sanitized);
  if (result.success) {
    return { success: true, data: normalizeDesignSpec(result.data) };
  } else {
    // If safeParse still found strict type issues, sanitize further and produce clean valid spec
    try {
      const fallbackSpec: DesignSpec = {
        meta: {
          title: sanitized.meta?.title || 'Extracted Design System',
          theme: sanitized.meta?.theme || 'dark',
          industry: sanitized.meta?.industry || 'tech',
          styleTags: sanitized.meta?.styleTags || ['dark', 'minimal'],
          sections: sanitized.meta?.sections || ['hero', 'features'],
          summary: sanitized.meta?.summary || 'Extracted design system.',
          description: sanitized.meta?.description || 'Precision design tokens and component specs.',
        },
        colors: sanitized.colors || [],
        typography: sanitized.typography,
        spacing: sanitized.spacing,
        surfaces: sanitized.surfaces || [],
        components: sanitized.components || [],
        dosAndDonts: sanitized.dosAndDonts || { dos: [], donts: [] },
      };
      return { success: true, data: normalizeDesignSpec(fallbackSpec) };
    } catch {
      const errors = result.error.issues.map(e => `${e.path.join('.')}: ${e.message}`);
      return { success: false, errors };
    }
  }
}

export function validateAnalyzeResult(data: unknown): { success: boolean; data?: AnalyzeResult; errors?: string[] } {
  const result = AnalyzeResultSchema.safeParse(data);
  if (result.success) {
    return { success: true, data: result.data };
  } else {
    const errors = result.error.issues.map(e => `${e.path.join('.')}: ${e.message}`);
    return { success: false, errors };
  }
}
