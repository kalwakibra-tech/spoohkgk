/**
 * Shared TypeScript types for Loupe
 * Document 2, Section 5.7
 */

export interface ColorToken {
  name: string;
  value: string;
  token: string;
  role: string;
}

export interface TypeScaleItem {
  role: string;
  family: string;
  weight: number | string;
  size: number | string;
  lineHeight: number | string;
  letterSpacing: number | string;
  token: string;
}

export interface TypefaceInfo {
  name: string;
  substitute: string;
  role: string;
  weights: (number | string)[];
  sizes: (number | string)[];
  lineHeight: string;
  letterSpacing: string;
  token: string;
}

export interface SpacingItem {
  name: string;
  value: string;
  token: string;
}

export interface RadiusItem {
  element: string;
  value: string;
  token?: string;
}

export interface ElevationItem {
  name: string;
  value: string;
  token: string;
}

export interface SurfaceItem {
  level: number;
  name: string;
  value: string;
  purpose: string;
}

export interface ComponentSpec {
  name: string;
  role: string;
  description: string;
  props?: Record<string, string>;
  tokensUsed?: string[];
}

export interface DesignSpec {
  meta: {
    title: string;
    theme: 'dark' | 'light' | 'mixed';
    industry: string;
    styleTags: string[];
    sections: string[];
    summary: string;
    description: string;
  };
  colors: ColorToken[];
  typography: {
    primaryFont: TypefaceInfo;
    secondaryFont?: TypefaceInfo;
    utilityFont?: TypefaceInfo;
    typeScale: TypeScaleItem[];
  };
  spacing: {
    baseUnit: number;
    density: string;
    scale: SpacingItem[];
    radii: RadiusItem[];
    shadows: ElevationItem[];
    layout: {
      pageMaxWidth: string;
      sectionGap: string;
      cardPadding: string;
      elementGap: string;
    };
  };
  surfaces: SurfaceItem[];
  components: ComponentSpec[];
  dosAndDonts: {
    dos: string[];
    donts: string[];
  };
}

export interface ResultImage {
  name: string;
  width: number;
  height: number;
  thumbDataUrl: string;
  dataUrl: string;
}

export interface Result {
  id: string;
  createdAt: number;
  cacheKey: string;
  title: string;
  tags: {
    industry: string[];
    style: string[];
    sections: string[];
  };
  markdown: string;
  spec: DesignSpec;
  images: ResultImage[];
  shareId?: string;
}

export interface ShareDoc {
  title: string;
  markdown: string;
  tags: {
    industry: string[];
    style: string[];
    sections: string[];
  };
  imageCount: number;
  coverImage: string;
  deviceId: string;
  createdAt: any;
  copyCount: number;
  visibility: 'unlisted' | 'public';
  publicAt?: any;
  publicCopyCount?: number;
}

export interface ShareImageDoc {
  index: number;
  mime: string;
  width: number;
  height: number;
  dataUrl: string;
}

export interface Measurements {
  palette: { hex: string; role?: string; percentage?: number }[];
  dimensions: { width: number; height: number; aspectRatio: number }[];
}

export interface SiteGroup {
  id: string;
  label: string;
  description: string;
  sections: string[];
  imageIndices: number[];
}

export interface AnalyzeResult {
  isWebsite: boolean;
  rejectionCode?: string | null;
  rejectionReason?: string | null;
  sites: SiteGroup[];
}

export type StepName = 'check' | 'measure' | 'analyze' | 'extract' | 'validate';

export type PipelineEvent =
  | { type: 'step'; step: StepName; status: 'active' | 'done' }
  | { type: 'retry'; inSeconds: number; attempt: number }
  | { type: 'cache_hit'; resultId: string }
  | { type: 'rejected'; items: { fileName: string; code: string; reason?: string }[] }
  | { type: 'done'; resultIds: string[] }
  | { type: 'error'; error: Error | { code?: string; message: string } };

export interface PipelineOptions {
  signal: AbortSignal;
  onEvent: (event: PipelineEvent) => void;
  requestChoice: (sites: SiteGroup[]) => Promise<{ siteIds: string[] }>;
}
