/**
 * S1 Landing Page
 * Document 2, Section 4.1 & Document 1, Section 5.2
 */
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, ChevronDown } from 'lucide-react';
import { listPublic } from '../storage/remote';
import { ShareDoc } from '../types';
import { LibraryCard } from '../components/LibraryCard';

export const LandingPage: React.FC = () => {
  const [teaserItems, setTeaserItems] = useState<(ShareDoc & { id: string })[]>([]);
  const [loadingTeaser, setLoadingTeaser] = useState(true);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  useEffect(() => {
    let mounted = true;
    async function loadTeaser() {
      try {
        const res = await listPublic({ sort: 'new', pageSize: 6 });
        if (mounted) {
          setTeaserItems(res.items.slice(0, 6));
          setLoadingTeaser(false);
        }
      } catch {
        if (mounted) setLoadingTeaser(false);
      }
    }
    loadTeaser();
    return () => {
      mounted = false;
    };
  }, []);

  const faqs = [
    {
      q: 'What is Loupe?',
      a: 'Loupe acts like a jeweler’s magnifying loupe for website design. It inspects screenshots in high fidelity and extracts a complete, structured design.md specification containing exact color tokens, typography scales, elevation layers, and component guidelines for AI builders.',
    },
    {
      q: 'What screenshot formats are supported?',
      a: 'PNG, JPG, and WEBP formats up to 8 images per run, up to 10 MB each, with minimum dimensions of 800×300 px.',
    },
    {
      q: 'How do I use the generated design.md?',
      a: 'Copy or download the file and paste it as the very first context prompt into Claude, Cursor, v0, Bolt, or Gemini. The AI builder uses the exact tokens and component hierarchy to reconstruct the interface.',
    },
    {
      q: 'What happens if I upload screenshots from multiple sites?',
      a: 'Loupe automatically detects when screenshots originate from different websites and provides an interactive choice screen to extract them individually or sequentially in a batch.',
    },
    {
      q: 'Is my data private?',
      a: 'Yes. All extracted results and images are stored locally in your browser’s IndexedDB. Results are only shared to the public library if you explicitly toggle "Publish to library".',
    },
    {
      q: 'How is the output structured?',
      a: 'The output follows a standardized, production-grade schema: Style Summary, Tokens (Colors, Typography, Spacing, Surfaces), Component Architecture, and actionable Do’s and Don’ts.',
    },
  ];

  return (
    <div className="w-full max-w-[1200px] mx-auto px-6 py-12 flex flex-col gap-20 text-center">
      {/* Hero Section */}
      <section className="flex flex-col items-center gap-8 pt-8">
        {/* Architectural whisper-weight display headline: max 14ch per line on desktop, 3 lines max */}
        <h1 className="text-4xl sm:text-6xl md:text-7xl font-normal text-white tracking-[-0.04em] leading-[1.05] max-w-[14ch] mx-auto">
          See the design. Rebuild it exactly.
        </h1>

        <p className="text-base sm:text-lg text-[#858585] tracking-[-0.015em] max-w-xl mx-auto">
          Drop website screenshots. Get a pixel-accurate <span className="text-white font-mono text-sm">design.md</span> with tokens, typography scales, and component specs for your AI builder.
        </p>

        {/* Hero Actions */}
        <div className="flex flex-wrap items-center justify-center gap-4">
          <Link
            to="/generate"
            data-testid="cta-try"
            className="bg-[#0063e1] hover:bg-[#0052be] text-white text-base font-normal tracking-[-0.007em] px-8 py-3.5 rounded-[59px] transition-all cursor-pointer shadow-none flex items-center gap-2"
          >
            Try it now
            <ArrowRight className="w-4 h-4" />
          </Link>
          <Link
            to="/s/rekki-control"
            data-testid="cta-example"
            className="bg-[#0d0d0d] hover:bg-[#1f1f1f] text-white text-base font-normal tracking-[-0.007em] px-6 py-3.5 rounded-[59px] inset-border transition-all cursor-pointer"
          >
            View example design.md
          </Link>
        </div>

        {/* CSS-only Hero Visual: Left wireframe card -> arrow -> Right monospace tokens */}
        <div className="w-full max-w-3xl mt-6 p-6 rounded-[24px] bg-[#040910] inset-border flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl">
          {/* Left card: Faint browser-window wireframe outline */}
          <div className="w-full md:w-[45%] h-52 bg-[#0d0d0d] rounded-[16px] inset-border p-3 flex flex-col gap-2 select-none">
            <div className="flex items-center gap-1.5 pb-2 border-b border-[rgba(255,255,255,0.06)]">
              <div className="w-2 h-2 rounded-full bg-[#1f1f1f]" />
              <div className="w-2 h-2 rounded-full bg-[#1f1f1f]" />
              <div className="w-2 h-2 rounded-full bg-[#1f1f1f]" />
              <div className="w-32 h-2.5 bg-[#1f1f1f] rounded-full ml-2" />
            </div>
            <div className="flex-1 flex flex-col gap-2 pt-1">
              <div className="w-24 h-4 bg-[#1f1f1f] rounded-[4px]" />
              <div className="w-full h-8 bg-[#1f1f1f]/60 rounded-[6px]" />
              <div className="grid grid-cols-2 gap-2 mt-auto">
                <div className="h-14 bg-[#1f1f1f]/40 rounded-[8px]" />
                <div className="h-14 bg-[#1f1f1f]/40 rounded-[8px]" />
              </div>
            </div>
          </div>

          {/* Thin arrow */}
          <div className="text-[#858585] flex items-center justify-center">
            <ArrowRight className="w-6 h-6 rotate-90 md:rotate-0" />
          </div>

          {/* Right card: Monospace tokens sample */}
          <div className="w-full md:w-[45%] h-52 bg-[#0d0d0d] rounded-[16px] inset-border p-3 flex flex-col text-left font-mono text-[11px] leading-relaxed text-[#858585] overflow-hidden select-none">
            <span className="text-white font-medium"># DESIGN.md: REKKI</span>
            <span className="text-white mt-1">## Tokens — Colors</span>
            <span className="text-white">--color-signal-blue: #0063E1;</span>
            <span>--color-obsidian: #000000;</span>
            <span>--color-carbon: #040910;</span>
            <span className="text-white mt-1">## Tokens — Typography</span>
            <span>--font-primary: Diatype REKKI;</span>
            <span>--radius-buttons: 59px;</span>
          </div>
        </div>
      </section>

      {/* Library Teaser Section */}
      <section className="flex flex-col gap-8 text-left">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-normal text-white tracking-[-0.027em]">
              Community Library
            </h2>
            <p className="text-sm text-[#858585] mt-1">
              Browse recent production-grade design specifications extracted by Loupe.
            </p>
          </div>
          <Link
            to="/library"
            className="text-sm text-[#858585] hover:text-white flex items-center gap-1 transition-colors"
          >
            View all
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div data-testid="teaser-grid" className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {loadingTeaser ? (
            Array.from({ length: 6 }).map((_, i) => (
              <div
                key={i}
                className="h-64 rounded-[16px] bg-[#0d0d0d] inset-border animate-pulse"
              />
            ))
          ) : teaserItems.length > 0 ? (
            teaserItems.map((item) => <LibraryCard key={item.id} item={item} />)
          ) : (
            <p className="text-sm text-[#858585] col-span-3">No public designs found yet.</p>
          )}
        </div>
      </section>

      {/* FAQ Section */}
      <section className="flex flex-col gap-8 text-left max-w-3xl mx-auto w-full">
        <div className="text-center">
          <h2 className="text-2xl font-normal text-white tracking-[-0.027em]">
            Frequently Asked Questions
          </h2>
          <p className="text-sm text-[#858585] mt-1">
            Everything you need to know about Loupe and the design.md format.
          </p>
        </div>

        <div className="flex flex-col gap-3">
          {faqs.map((faq, idx) => {
            const isOpen = openFaq === idx;
            return (
              <div
                key={idx}
                data-testid={`faq-item-${idx + 1}`}
                className="rounded-[16px] bg-[#0d0d0d] inset-border overflow-hidden transition-all"
              >
                <button
                  type="button"
                  onClick={() => setOpenFaq(isOpen ? null : idx)}
                  className="w-full p-5 flex items-center justify-between text-left cursor-pointer"
                  aria-expanded={isOpen}
                >
                  <span className="text-sm font-medium text-white">{faq.q}</span>
                  <ChevronDown
                    className={`w-4 h-4 text-[#858585] transition-transform ${
                      isOpen ? 'rotate-180 text-white' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-5 pb-5 text-sm text-[#858585] leading-relaxed border-t border-[rgba(255,255,255,0.04)] pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
