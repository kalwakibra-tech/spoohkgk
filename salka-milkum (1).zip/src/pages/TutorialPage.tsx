/**
 * S11 Tutorial Screen
 * Document 2, Section 4.10 & Document 1, Section 5.3
 */
import React from 'react';
import { Link } from 'react-router-dom';
import {
  Camera,
  Layers,
  Sparkles,
  FileCode,
  Share2,
  CheckCircle2,
  XCircle,
  ArrowRight,
} from 'lucide-react';

export const TutorialPage: React.FC = () => {
  const steps = [
    {
      num: '01',
      title: 'Capture High-Resolution Screenshots',
      icon: Camera,
      description:
        'Use native browser full-page capture or screenshot shortcuts at 1440px or 1920px desktop width. Ensure text and UI controls are sharp and unscaled.',
      tips: [
        'Dismiss cookie banners, chat widgets, and promotional overlays first.',
        'Use dark mode if targeting dark theme, or light mode for light theme.',
        'Include both hero sections and complex component states.',
      ],
    },
    {
      num: '02',
      title: 'Upload to Loupe',
      icon: Layers,
      description:
        'Drop 1 to 8 screenshots directly into Loupe, paste from clipboard (Ctrl+V), or select files. Loupe inspects each file for resolution, clarity, and dimensions.',
      tips: [
        'Order matters: place your primary hero or homepage view first.',
        'Drag and drop or use the reorder buttons to set the order.',
        'If uploading multiple sites, Loupe detects them and lets you choose.',
      ],
    },
    {
      num: '03',
      title: 'Automated Measurement & Extraction',
      icon: Sparkles,
      description:
        'Loupe runs a multi-stage pipeline: palette extraction, geometry calculation, website verification, token extraction, and schema validation.',
      tips: [
        'Colors are clustered and mapped to semantic roles (background, surface, primary).',
        'Typography scales extract exact font families, weights, sizes, and tracking.',
        'Surfaces and elevations are detected as layered CSS custom properties.',
      ],
    },
    {
      num: '04',
      title: 'Feed design.md into AI Builders',
      icon: FileCode,
      description:
        'Copy the generated design.md file and paste it as the very first prompt into your AI coding workflow (AI Studio, Cursor, Claude, v0).',
      tips: [
        'Tell the AI: "Adopt this design.md specification exactly for all components and styling."',
        'Tokens provide ready-to-use Tailwind v4 variables and CSS properties.',
        'Components include exact padding, radii, and color references.',
      ],
    },
  ];

  return (
    <div className="max-w-[1000px] mx-auto px-6 py-12 flex flex-col gap-12 text-left">
      {/* Header */}
      <div className="flex flex-col gap-3">
        <span className="text-xs uppercase tracking-widest text-[#0063e1] font-semibold">
          Tutorial & Guide
        </span>
        <h1 className="text-3xl md:text-4xl font-normal text-white tracking-tight">
          How to get pixel-accurate specs with Loupe
        </h1>
        <p className="text-sm md:text-base text-[#858585] max-w-2xl">
          Loupe inspects website screenshots with microscope fidelity and produces a comprehensive, production-ready <code className="text-white bg-[#1f1f1f] px-1.5 py-0.5 rounded text-xs font-mono">design.md</code> file tailored for AI web app builders.
        </p>
      </div>

      {/* Steps List */}
      <div className="flex flex-col gap-8">
        {steps.map((step) => {
          const Icon = step.icon;
          return (
            <div
              key={step.num}
              className="bg-[#0a0a0a] border border-[#1f1f1f] rounded-[20px] p-6 md:p-8 flex flex-col md:flex-row gap-6 items-start"
            >
              <div className="flex items-center justify-center w-12 h-12 rounded-[14px] bg-[#040910] border border-[#1f1f1f] text-[#0063e1] shrink-0 font-mono text-sm font-semibold">
                {step.num}
              </div>
              <div className="flex-1 flex flex-col gap-3">
                <div className="flex items-center gap-3">
                  <h2 className="text-lg md:text-xl font-medium text-white">
                    {step.title}
                  </h2>
                </div>
                <p className="text-sm text-[#858585] leading-relaxed">
                  {step.description}
                </p>
                <div className="bg-[#040910] border border-[#1f1f1f] rounded-[12px] p-4 mt-2">
                  <span className="text-xs uppercase tracking-wider text-[#858585] font-semibold block mb-2">
                    Pro Tips
                  </span>
                  <ul className="flex flex-col gap-1.5 text-xs text-[#a0a0a0]">
                    {step.tips.map((tip, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-[#0063e1] mt-0.5">•</span>
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Do's and Don'ts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-[#0a0a0a] border border-[#1f1f1f] rounded-[16px] p-6 flex flex-col gap-4">
          <div className="flex items-center gap-2 text-emerald-400">
            <CheckCircle2 className="w-5 h-5" />
            <h3 className="text-base font-medium text-white">Do</h3>
          </div>
          <ul className="flex flex-col gap-2.5 text-xs text-[#858585]">
            <li className="flex items-start gap-2">
              <span className="text-emerald-400">✓</span>
              <span>Upload uncompressed PNG or WebP screenshots taken on a desktop viewport.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-400">✓</span>
              <span>Include 2-4 pages from the same site for the richest multi-page token analysis.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-400">✓</span>
              <span>Use the Raw tab to copy the pure markdown directly into AI prompts.</span>
            </li>
          </ul>
        </div>

        <div className="bg-[#0a0a0a] border border-[#1f1f1f] rounded-[16px] p-6 flex flex-col gap-4">
          <div className="flex items-center gap-2 text-rose-400">
            <XCircle className="w-5 h-5" />
            <h3 className="text-base font-medium text-white">Don't</h3>
          </div>
          <ul className="flex flex-col gap-2.5 text-xs text-[#858585]">
            <li className="flex items-start gap-2">
              <span className="text-rose-400">✕</span>
              <span>Don't upload photos of computer screens taken with a phone camera (they will be rejected as blurry or non-website).</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-400">✕</span>
              <span>Don't crop too tightly: include surrounding margins and headers to reveal layout grids.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-400">✕</span>
              <span>Don't leave mock or sample banners covering the main navigation.</span>
            </li>
          </ul>
        </div>
      </div>

      {/* CTA Footer */}
      <div className="bg-gradient-to-r from-[#040910] to-[#0a0a0a] border border-[#1f1f1f] rounded-[20px] p-8 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="flex flex-col gap-1 text-center sm:text-left">
          <h3 className="text-xl font-medium text-white">Ready to inspect your first design?</h3>
          <p className="text-xs text-[#858585]">Drop a screenshot now and get your full design.md in seconds.</p>
        </div>
        <Link
          to="/generate"
          className="inline-flex items-center gap-2 bg-[#0063e1] hover:bg-[#0051b8] text-white px-6 py-3 rounded-full text-sm font-medium transition-colors shrink-0"
        >
          <span>Launch Generator</span>
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
};
